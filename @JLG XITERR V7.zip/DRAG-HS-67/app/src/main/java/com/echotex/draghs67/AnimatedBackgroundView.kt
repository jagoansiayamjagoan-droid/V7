package com.echotex.draghs67

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import java.util.Random
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Latar belakang sinematik: langit malam gradasi, cahaya aurora yang bergeser pelan,
 * dan hujan salju 3 lapis (jauh, tengah, dekat) dengan efek paralaks.
 * Seluruh animasi berulang mulus (siklus bilangan bulat) dan berhenti saat layar tidak terlihat.
 */
class AnimatedBackgroundView(ctx: Context) : View(ctx) {

    private class Layer(
        val count: Int,
        val cycles: Int,
        val minR: Float,
        val maxR: Float,
        val alpha: Int,
        val sway: Float
    )

    private val layers = listOf(
        Layer(60, 1, 0.8f, 1.4f, 110, 6f),   // jauh: kecil, lambat, redup
        Layer(45, 2, 1.2f, 2.0f, 170, 10f),  // tengah
        Layer(18, 3, 2.0f, 3.2f, 235, 16f)   // dekat: besar, cepat, terang
    )

    private val rnd = Random(21)
    private val fx = Array(layers.size) { l -> FloatArray(layers[l].count) { rnd.nextFloat() } }
    private val fy = Array(layers.size) { l -> FloatArray(layers[l].count) { rnd.nextFloat() } }
    private val fr = Array(layers.size) { l -> FloatArray(layers[l].count) { rnd.nextFloat() } }
    private val fp = Array(layers.size) { l -> FloatArray(layers[l].count) { rnd.nextFloat() } }

    private val bgPaint = Paint()
    private val auroraPaint = Paint()
    private val flakePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    private var auroras: List<RadialGradient> = emptyList()
    private val auroraOffsets = floatArrayOf(0f, 0.33f, 0.66f)

    private var phase = 0f
    private val twoPi = (2.0 * PI).toFloat()

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 16000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bgPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(Color.rgb(1, 5, 18), Color.rgb(10, 26, 63), Color.rgb(22, 64, 106)),
            floatArrayOf(0f, 0.6f, 1f),
            Shader.TileMode.CLAMP
        )
        val r = w * 0.9f
        auroras = listOf(
            RadialGradient(w * 0.2f, h * 0.12f, r, Color.argb(75, 0, 229, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP),
            RadialGradient(w * 0.75f, h * 0.2f, r, Color.argb(55, 29, 233, 182), Color.TRANSPARENT, Shader.TileMode.CLAMP),
            RadialGradient(w * 0.5f, h * 0.05f, r, Color.argb(65, 41, 121, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (!animator.isStarted) return
        if (visibility == VISIBLE) animator.resume() else animator.pause()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return

        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // Aurora: cahaya lembut yang bergeser pelan ke kiri-kanan
        for (i in auroras.indices) {
            auroraPaint.shader = auroras[i]
            canvas.save()
            canvas.translate(sin((phase + auroraOffsets[i]) * twoPi) * w * 0.08f, 0f)
            canvas.drawRect(-w * 0.3f, 0f, w * 1.3f, h * 0.7f, auroraPaint)
            canvas.restore()
        }

        // Salju 3 lapis
        for (li in layers.indices) {
            val layer = layers[li]
            for (i in 0 until layer.count) {
                val r = context.dp(1) * (layer.minR + (layer.maxR - layer.minR) * fr[li][i])
                var yy = fy[li][i] + phase * layer.cycles
                yy -= floor(yy)
                val y = yy * (h + 2f * r) - r
                val x = fx[li][i] * w +
                    sin(phase * twoPi * layer.cycles + fp[li][i] * twoPi) * layer.sway * context.dp(1)
                if (li == 2) {
                    flakePaint.color = Color.WHITE
                    flakePaint.alpha = 40
                    canvas.drawCircle(x, y, r * 2.2f, flakePaint)
                }
                flakePaint.color = Color.WHITE
                flakePaint.alpha = layer.alpha
                canvas.drawCircle(x, y, r, flakePaint)
            }
        }
    }
}

/** Vinyet gelap di tepi layar untuk kesan sinematik. Tidak menangkap sentuhan. */
class VignetteView(ctx: Context) : View(ctx) {

    private val paint = Paint()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        paint.shader = RadialGradient(
            w / 2f, h / 2f, hypot(w.toFloat(), h.toFloat()) * 0.62f,
            intArrayOf(Color.TRANSPARENT, Color.argb(150, 0, 0, 0)),
            floatArrayOf(0.55f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }
}
