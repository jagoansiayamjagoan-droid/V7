package com.echotex.draghs67

import android.app.Activity
import android.content.Context
import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import kotlin.math.sin
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Random
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Mode latihan lokal di dalam aplikasi. Seret jari untuk menggerakkan crosshair virtual;
 * sensitivitas menentukan seberapa jauh crosshair bergerak per jarak seretan.
 * Tidak berhubungan dengan Free Fire dan tidak mengubah pengaturan game apa pun.
 */
class TrainingActivity : Activity() {

    private lateinit var repo: SettingsRepository
    private lateinit var stats: TextView
    private lateinit var target: TargetView
    private lateinit var control: SensitivityControl
    private var streak = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = SettingsRepository(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(16))
        }

        val title = Ui.label(this, "TRAINING 3D", 24f, R.color.neon_cyan, true).apply {
            gravity = Gravity.CENTER
            Ui.neon(this, R.color.neon_cyan)
        }
        val hint = Ui.label(
            this,
            "Seret jari untuk menggeser crosshair ke bola target 3D, lalu lepas untuk menembak (simulasi). Target lebih jauh tampil lebih kecil.",
            11f, R.color.text_dim
        ).apply { setPadding(0, dp(6), 0, dp(6)) }
        stats = Ui.label(this, "", 12f, R.color.text_primary)

        target = TargetView(this) { hit -> onResult(hit) }.apply {
            factor = factorFor(repo.sensitivity)
            minimumHeight = dp(180)
            layoutParams = LinearLayout.LayoutParams(Ui.MATCH, 0, 1f).apply {
                topMargin = dp(8)
                bottomMargin = dp(8)
            }
        }

        control = sensitivityControl(this, repo) { v ->
            target.factor = factorFor(v)
            refreshStats()
        }

        val reset = Ui.neonButton(this, "RESET", R.color.danger, 48).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) }
            setOnClickListener {
                repo.resetAll()
                streak = 0
                control.refresh()
                target.factor = factorFor(repo.sensitivity)
                refreshStats()
            }
        }
        val backBtn = Ui.neonButton(this, "KEMBALI", R.color.electric_blue, 48).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) }
            setOnClickListener { Ui.back(this@TrainingActivity) }
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(reset)
            addView(backBtn)
        }

        root.addView(title)
        root.addView(Ui.cloudBanner(this, 56).apply { (layoutParams as LinearLayout.LayoutParams).topMargin = dp(8) })
        root.addView(hint)
        root.addView(stats)
        root.addView(target)
        root.addView(control.view)
        root.addView(buttons)
        root.addView(Ui.watermark(this))
        setContentView(Ui.animatedScreen(this, root))
        refreshStats()
    }

    private fun onResult(hit: Boolean) {
        repo.attempts += 1
        if (hit) {
            repo.hits += 1
            streak += 1
            if (streak > repo.bestStreak) repo.bestStreak = streak
        } else {
            streak = 0
        }
        refreshStats()
    }

    private fun refreshStats() {
        val attempts = repo.attempts
        val acc = if (attempts > 0) repo.hits * 100 / attempts else 0
        stats.text = "TEMBAKAN $attempts | KENA ${repo.hits} | AKURASI $acc%\n" +
            "STREAK $streak (terbaik ${repo.bestStreak}) | GERAK x${"%.2f".format(target.factor)}"
    }

    companion object {
        /** Pengali gerak crosshair: sensitivitas 0 -> 0.20, 67 -> 1.41, 100 -> 2.00. */
        fun factorFor(sensitivity: Int): Float = 0.2f + sensitivity.coerceIn(0, 100) * 0.018f
    }
}

class TargetView(ctx: Context, private val onResult: (Boolean) -> Unit) : View(ctx) {

    var factor = 1.4f

    private val cyan = ctx.getColor(R.color.neon_cyan)
    private val blue = ctx.getColor(R.color.electric_blue)
    private val green = ctx.getColor(R.color.ok_green)
    private val red = ctx.getColor(R.color.danger)

    // Shader bola berjari-jari 1 (disorot dari kiri-atas); diskalakan lewat canvas saat digambar
    private fun sphere(c1: Int, c2: Int, c3: Int) = RadialGradient(
        -0.35f, -0.35f, 1.5f,
        intArrayOf(Color.WHITE, c1, c2, c3), floatArrayOf(0f, 0.3f, 0.7f, 1f),
        Shader.TileMode.CLAMP
    )

    private val cyanSphere = sphere(cyan, blue, Color.rgb(5, 20, 60))
    private val greenSphere = sphere(green, Color.rgb(0, 120, 70), Color.rgb(0, 40, 25))
    private val redSphere = sphere(red, Color.rgb(150, 0, 30), Color.rgb(50, 0, 10))

    private val skyPaint = Paint()
    private val floorPaint = Paint()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        color = cyan
    }
    private val trail = Path()
    private val rnd = Random()

    // Kamera sederhana: f = panjang fokus (piksel), horizon di (hx, hy), tinggi mata 1 m
    private val targetR = 0.28f
    private var f = 1f
    private var hx = 0f
    private var hy = 0f

    // Target (posisi layar + kedalaman Z dalam meter)
    private var tsx = 0f
    private var tsy = 0f
    private var tz = 5f
    private var radiusPx = 0f
    private var spawnAt = 0L

    private var cx = 0f
    private var cy = 0f
    private var downX = 0f
    private var downY = 0f
    private var baseX = 0f
    private var baseY = 0f
    private var dragging = false
    private var locked = false
    private var lastHit: Boolean? = null
    private var shakeUntil = 0L

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }

    init {
        val radius = ctx.dp(14).toFloat()
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        clipToOutline = true
        foreground = Ui.rounded(ctx, Color.TRANSPARENT, blue, 14)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        f = min(w, h) * 1.96f
        hx = w / 2f
        hy = h * 0.42f
        skyPaint.shader = LinearGradient(
            0f, 0f, 0f, hy, Color.rgb(2, 8, 24), Color.rgb(20, 52, 96), Shader.TileMode.CLAMP
        )
        floorPaint.shader = LinearGradient(
            0f, hy, 0f, h.toFloat(), Color.rgb(10, 30, 60), Color.rgb(2, 8, 20), Shader.TileMode.CLAMP
        )
        newRound()
    }

    private fun easeOutBack(x: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        val y = x - 1f
        return 1f + c3 * y * y * y + c1 * y * y
    }

    private fun newRound() {
        if (width == 0 || height == 0) return
        cx = width / 2f
        cy = height / 2f
        var tries = 0
        do {
            tz = 3f + rnd.nextFloat() * 4f
            val r = targetR / tz * f
            val minY = r + context.dp(6)
            val maxY = hy + (1f - targetR - 0.05f) / tz * f
            tsx = r + rnd.nextFloat() * max(1f, width - 2 * r)
            tsy = minY + rnd.nextFloat() * max(1f, maxY - minY)
            radiusPx = r
            tries++
        } while (hypot(tsx - cx, tsy - cy) < radiusPx * 2f && tries < 15)
        spawnAt = SystemClock.uptimeMillis()
        trail.reset()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val now = SystemClock.uptimeMillis()
        val d1 = context.dp(1).toFloat().coerceAtLeast(1f)

        canvas.save()
        val left = shakeUntil - now
        if (left > 0) {
            val a = context.dp(4) * (left / 160f)
            canvas.translate((rnd.nextFloat() - 0.5f) * a * 2f, (rnd.nextFloat() - 0.5f) * a * 2f)
        }

        // Langit & lantai
        canvas.drawRect(0f, 0f, w, hy, skyPaint)
        canvas.drawRect(0f, hy, w, h, floorPaint)

        // Garis horizon bercahaya
        linePaint.color = cyan
        linePaint.alpha = 130
        linePaint.strokeWidth = d1 * 1.5f
        canvas.drawLine(0f, hy, w, hy, linePaint)

        // Grid lantai berperspektif
        linePaint.color = blue
        linePaint.strokeWidth = d1
        val zs = floatArrayOf(1.8f, 2.2f, 2.7f, 3.3f, 4f, 5f, 6.3f, 8f, 10f, 13f)
        for (z in zs) {
            val y = hy + 1f / z * f
            if (y > h) continue
            linePaint.alpha = (140 - 8 * z).toInt().coerceIn(30, 140)
            canvas.drawLine(0f, y, w, y, linePaint)
        }
        val zNear = 1.6f
        val zFar = 16f
        linePaint.alpha = 60
        for (xi in -8..8) {
            canvas.drawLine(
                hx + xi / zNear * f, hy + 1f / zNear * f,
                hx + xi / zFar * f, hy + 1f / zFar * f,
                linePaint
            )
        }

        // Target 3D: bayangan di lantai, tiang, cahaya, bola berbayang
        val bob = sin(now / 600f) * 0.03f
        val sc = easeOutBack(((now - spawnAt) / 300f).coerceIn(0f, 1f))
        val r = radiusPx * sc
        val ty = tsy - bob / tz * f
        val floorY = hy + 1f / tz * f

        fillPaint.shader = null
        fillPaint.color = Color.BLACK
        fillPaint.alpha = 110
        canvas.save()
        canvas.translate(tsx, floorY)
        canvas.scale(1f, 0.22f)
        canvas.drawCircle(0f, 0f, radiusPx * 0.95f, fillPaint)
        canvas.restore()

        linePaint.color = Color.rgb(150, 185, 220)
        linePaint.alpha = 110
        linePaint.strokeWidth = max(d1, radiusPx * 0.07f)
        canvas.drawLine(tsx, floorY, tsx, ty + r * 0.9f, linePaint)

        val state = lastHit
        val base = when (state) {
            true -> green
            false -> red
            null -> cyan
        }
        fillPaint.color = base
        fillPaint.alpha = 40
        canvas.drawCircle(tsx, ty, r * 1.35f, fillPaint)

        canvas.save()
        canvas.translate(tsx, ty)
        canvas.scale(r, r)
        fillPaint.shader = when (state) {
            true -> greenSphere
            false -> redSphere
            null -> cyanSphere
        }
        fillPaint.alpha = 255
        canvas.drawCircle(0f, 0f, 1f, fillPaint)
        canvas.restore()
        fillPaint.shader = null

        // Cincin bullseye di permukaan bola + kilau
        linePaint.color = Color.WHITE
        linePaint.alpha = 150
        linePaint.strokeWidth = d1 * 1.5f
        canvas.drawCircle(tsx, ty, r * 0.55f, linePaint)
        linePaint.alpha = 90
        canvas.drawCircle(tsx, ty, r, linePaint)
        fillPaint.color = Color.WHITE
        fillPaint.alpha = 200
        canvas.drawCircle(tsx - r * 0.35f, ty - r * 0.4f, r * 0.14f, fillPaint)

        // Jejak seretan + crosshair
        linePaint.color = blue
        linePaint.alpha = 220
        linePaint.strokeWidth = d1 * 2f
        canvas.drawPath(trail, linePaint)

        val arm = radiusPx.coerceAtLeast(context.dp(14).toFloat()) * 0.6f
        linePaint.color = Color.WHITE
        linePaint.alpha = 255
        linePaint.strokeWidth = d1 * 2f
        canvas.drawLine(cx - arm, cy, cx + arm, cy, linePaint)
        canvas.drawLine(cx, cy - arm, cx, cy + arm, linePaint)
        canvas.drawCircle(cx, cy, arm * 0.35f, linePaint)

        // Info jarak
        textPaint.textSize = context.dp(11).toFloat()
        textPaint.alpha = 170
        canvas.drawText("JARAK ${"%.1f".format(tz)} m", context.dp(10).toFloat(), h - context.dp(10), textPaint)

        canvas.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (locked) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                downX = e.x
                downY = e.y
                baseX = cx
                baseY = cy
                trail.reset()
                trail.moveTo(cx, cy)
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    cx = (baseX + (e.x - downX) * factor).coerceIn(0f, width.toFloat())
                    cy = (baseY + (e.y - downY) * factor).coerceIn(0f, height.toFloat())
                    trail.lineTo(cx, cy)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    dragging = false
                    finishShot()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                newRound()
            }
        }
        return true
    }

    private fun finishShot() {
        val hit = hypot(cx - tsx, cy - tsy) <= radiusPx
        lastHit = hit
        locked = true
        shakeUntil = SystemClock.uptimeMillis() + 160
        invalidate()
        onResult(hit)
        postDelayed({
            locked = false
            lastHit = null
            newRound()
        }, 400)
    }
}
